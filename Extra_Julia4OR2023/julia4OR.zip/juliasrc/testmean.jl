using Statistics
A = rand(0:99, 10)
println(A)
println(mean(A))
